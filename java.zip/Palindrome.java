
import java.util.Scanner;
class Palindrome {
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter number to check palindrome");
        int n = sc.nextInt();
        
        int r,sum=0,rev;
        rev=n;
        while (n>0){
        r=n%10;
        sum=(sum*10)+r;
        n=n/10;
        }
        if (rev==sum){
            System.out.println("the number is palindrome");

        }
        else{
            System.out.println("the number is not palindrome");
        }
      }
    }  

