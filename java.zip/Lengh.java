import java.util.Scanner;

class Interest {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Profit");
    String P = sc.nextInt();
    System.out.println("Time");
    String T = sc.nextInt();
    System.out.println("rate");
    String R = sc.nextInt();

    S=P*T*R;
    System.out.println("" + length);
  }
}