

public class Exception {
    public static void main(String[] args) {
        try {
            int a=10/1;
            System.out.println("result:"+a);
        }
        catch  (ArithmeticException e) {
            System.out.println("error in division by zero");
        }
finally {
    System.out.println("this is finally block");
     
}
System.out.println("rest of code");
        }
    }
    


