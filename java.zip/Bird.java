package demo;
class Bird
{
    void fly()
    {
      System.err.println("Bird can fly");
    }
class Parot extends Bird
    {
        void color()
        {
            System.err.println("iam green");
        }
    }
    
}

public class main
{
    public static void main(String[] args) 
    {
      Parot p=new Parot();
      p.color();
      p.fly();

    }
}