class Person {
    private String name;
    private int Age;

    public String getname() {
        return name;

    }

    public void setname(String name) {
        if (name != null && name.isEmpty()) {
            System.out.println("invalid name" + name);
        } else {
            this.name = name;
        }
    }

    public int getAge() {
        return Age;

    }

    public void setAge(int Age) {
        if (Age > 0) {
            this.Age = Age;

        } else {
            System.out.println("invalid age" + Age);

        }
    }
}

public class Encapsulation {
    public static void main(String[] args) {
        Person person = new Person();

        person.setname("sangeetha");
        person.setAge(19);
        System.out.println("Name:" + person.getname());
        System.out.println("Age:" + person.getAge());

    }
}