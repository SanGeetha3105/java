import java.util.Scanner;

class Interest {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("principal Amount:");
    float P = sc.nextInt();
    System.out.println("Time");
    float T = sc.nextInt();
    System.out.println("rate");
    float R = sc.nextInt();

    float S=(P*T*R)/100;
    System.out.println("interest:" + S);
  }
}