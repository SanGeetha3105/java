import java.util.Scanner;

public class Greater
{
public static void main(String[] args){
  Scanner scanner = new Scanner (System.in);
  System.out.println("enter input");
   int n1=scanner.nextInt();
  System.out.println("enter input");
   int n2=scanner.nextInt();
  System.out.println("enter input");
  int n3=scanner.nextInt();

  if(n1>n2 && n1>n3){
   System.out.println("n1 is greater");
  }
  else if (n2>n1 && n2>n3){
   System.out.println("n2 is greater");
  }
  else{
   System.out.println("n3 is greater");
  }
}
}
