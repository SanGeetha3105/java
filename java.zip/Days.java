public class Days 
{
   
    public static void main(String[] args) 
    {
        int choice=8;
        
        switch(choice)
        {
            case 1:
               b b b  System.out.println("Monday");
              break;
            case 2:
              System.out.println("Tuesday");
              break;
            case 3:
              System.out.println("wednesday");
              break;
            case 4:
              System.out.println("thursday");
              break;
            case 5:
              System.out.println("Friday");
              break;           
            case 6:
              System.out.println("Saturday");
              break;
            case 7:
              System.out.println("heyyy its weekend....jolly day");
              break;

            default:
              System.out.println("error,,u entered wrong input");
              
              
        }
    }
}



        