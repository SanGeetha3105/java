class Car1 {
    private String ModelName ;
    private String owner;
    private int regNumber;

    public Car1(String ModelName,String owner,int regNumber)
    {
      this.ModelName=ModelName;
      this.owner=owner;
      this.regNumber=regNumber; 
}

public void startEngine(){
  System.out.println("car can be started");
}
public void accelerate(){
    System.out.println("car can be accelerate");
}
public void stop(){
    System.out.println("car can be stopped");
}

public void showCarInformation(){
    System.out.println("the car is owned by "+owner);
    System.out.println("the car model is "+ModelName);
    System.out.println("the car reg no "+regNumber);
}
public static void main(String[] var0){
    Car1 myCar = new Car1 ("suzuki","sangeetha",123);
    myCar.startEngine();
    myCar.accelerate();
    myCar.stop();


myCar.showCarInformation();
}
}
