
import java.time.chrono.ThaiBuddhistChronology;

class Car1 {
    private String ModelName ;
    private String owner;
    private int regNumber;

    public class(String ModelName,String owner,int regNumber){
      this.ModelName=ModelName;
      this.owner=owner;
      this.regnumber=regNumber;
}

public void startEngine(){
  System.out.println("car can be started")
}
public void accelerate(){
    System.out.println("car can be accelerate")
}
public void stop(){
    System.out.println("car can be stopped")
}

public void showCarInformation(){
    System.out.println("the car is owned by "+owner);
    System.out.println("the car model is "+modelName);
    System.out.println("the car reg no "+regNumber);
}
public static void main(String[] args){
    Car1 myCar = new Car()(modelname:"suzuki",owner:"sangeetha",regNumber:123);
myCar.startEngine();
myCar.accelerate();
myCar.stop();
myCar.showcarinformation();
}
}
