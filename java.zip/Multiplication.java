import java.util.Scanner;
class Multiplication{
    public static void main(String[] args)
{
    Scanner sc = new Scanner (System.in);
    System.out.println("enter a number");
    float a=sc.nextInt();
    System.out.println("enter a number");
    float b=sc.nextInt();
    float c=a*b;
    System.out.println("multiplication of two numbers" +c);
}    
}
 