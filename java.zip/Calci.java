import java.util.Scanner;
class Calci{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
       
        System.out.println("enter choice");
        int ch= sc.nextInt();
        
        System.out.println("enter 1st no");
        int a = sc.nextInt();
       
        System.out.println("enter 2nd no");
        int b = sc.nextInt();
    
        switch(ch){
        case 1: 
           int c=a+b;
             System.out.println("addition of two numbers" +c);
            break;
        case 2:
             c=a-b;
             System.out.println("subtraction of two numbers"+c);
             break;
        case 3:
             c=a*b;
             System.out.println("multiplication:"+c);
             break;
        case 4:
            c=a/b;
            System.out.println("division:"+c);
            break;
        case 5:
           c=a%b;
           System.out.println("modulus:"+c);
           break;
        default :
           System.out.println("invalid choice");

    }


}
}
