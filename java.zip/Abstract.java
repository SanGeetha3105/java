abstract class Animal {
    public abstract void sound();
 public void sleep(){
    System.out.println("the animal is sleeping");
 }    
    
}
class Dog extends Animal{
   public void sound(){
     System.out.println("the dog barks");
   }
}
class Cat extends Animal{
   public void sound(){
      System.out.println("the cat meow");
}
}
public class Abstract{
   public static void main(String[] args) {
       Animal myCat = new Cat();
       Animal myDog =new Dog();
      
       myDog.sound();
       myCat.sound();

       myDog.sleep();
       myCat.sleep();


   }
}

