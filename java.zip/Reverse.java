
import java.util.Scanner;
public class Reverse {
    public static void main(String[] args) {
        String len= " ";
    
        Scanner sc = new Scanner(System.in);
        System.out.println("enter string:");
        String str= sc.nextLine();
        
        for ( int i=str.length() - 1 ; i>=0; i--){
           len+=str.charAt(i);
        }
         System.out.println("reverse of string:"+len);
    }
    
}
