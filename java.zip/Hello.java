class Hello
{
    public static void main(String[] args)
    {
      System.out.println("name=Sangetha");
      System.out.println("usn=1sv22cs093");
      System.out.println("3rd year");  
      System.out.println("CSE");  
      System.out.println("Shridevi institute of engg and techno");
    }
    System.out.println("CSE");
  }
  