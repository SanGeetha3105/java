class ClassObject {
    private String ModelName ;
    String owner;
 
}