public class Car {
    //public void Display(String name){
       // System.out.println("name:" +name);

  //  }

 
    //public static int square(int number) {
      //  return number * number;
   // }

    String brand;
    int year;

    public Car(  String brand,int year){
      this.brand = brand;
      this.year = year;

    }

    public void DisplayCarinfo(){
       System.out.println("car brand:"+brand);
       System.out.println("manufacturer:"+year);
    }
    public static void main(String[] args) {
        
    
        //InstanceMethod a= new InstanceMethod();
      //  a.Display("hiii");
     // int result = InstanceMethod.square(5);
      //System.out.println("square of 5 is:"+result);
    Car myCar = new Car("BMW",1995);
    myCar.DisplayCarinfo();
    
    }
    
}

