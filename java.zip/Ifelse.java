import java.util.Scanner;

public class Greater
{
public static void main(String[] args){
  Scanner scanner = new Scanner (System.in);
  Scanner scanner1 = new Scanner1 (System.in);
  System.out.println("enter input");
  System.out.println("enter input");
int n1=scanner.nextInt();
int n2=scanner1.nextInt();

if(n1>n2)
  System.out.println("n1 is greater",n1);

else 
  System.out.println("n2 is greater",n2);
}
}
