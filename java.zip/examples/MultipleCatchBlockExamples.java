

public class MultipleCatchBlockExamples {
    public static void main(String[] args) {
        try {
            int arr[]=new int[5]; 
            arr[5]=30/0;
          

        } catch(ArithmeticException e){
            System.out.println("Arithmatic exception divisible by zero");
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("ArrayIndexOutOfBoundsException:array index out of bound  ");
        }
    
    finally{
            System.out.println("exception some other exception occur");
        }
    
    }


}