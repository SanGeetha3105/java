import java.util.Scanner;

class Swap {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("enter number");
    int n1 = sc.nextInt();
    System.out.println("enter number");
    int n2= sc.nextInt();
    
     int temp = n1;
     n1 = n2;
     n2 = temp;
     System.out.println("after swap");
     System.out.println("n1:"+n1);
     System.out.println("n2:"+n2);
  }
}