import java.util.Scanner;

public class Voting {
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        System.out.println("enter input");
        int age=scanner.nextInt();
if ( age > 18){
    System.out.println("u are eligible to vote");
}
else {
    System.out.println("u are not eligible to vote please come afetr years..");
}
    }
    
}
